import React from "react"

const About = () => {
  return (
    <>
      <section className='about'>
        <h1>About Us</h1>
      </section>
    </>
  )
}

export default About
